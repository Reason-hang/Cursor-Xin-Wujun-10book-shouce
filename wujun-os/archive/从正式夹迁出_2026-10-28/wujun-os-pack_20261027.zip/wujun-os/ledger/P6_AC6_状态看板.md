# P6 AC-6 状态看板（2026-10-27）

| AC | 项 | 状态 | 证据/下一步 |
|---|---|---|---|
| 6.1 | G0–G9 全重跑 | 部分 | `make gates` + selftest 子集 |
| 6.2 | 核心论点覆盖 | 机械 PASS | `make p6-bidir-matrix`；语义待回读 |
| 6.3 | 抽检召回 | 未闭环 | pending=130/130 → `P6_抽检召回工作册.md` |
| 6.4 | 关键词反查 | 机械达标 | `make p6-g10-refresh` |
| 6.5 | 数理映射 | PASS | `make p6-math-audit` 50/50 |
| 6.6 | 应用 5 场景 | PASS | `make p6-app-lint` + ledger 演练稿 |
| 6.7 | 滑窗重复 | PASS | `make p6-dup-lint` |
| 6.8 | 锚点 | PASS | `make verify-anchors` |
| 6.9 | 对抗审查 | 待签收 | `P6_对抗式审查_签收表.md` |
| 6.10 | 用户试用 | 待你 | `P6_用户试用与抽查指引.md` |

**阻塞 P7**：D10 A/B（`R-D10-01_裁决附件_AB对比.md`）；P4 20 张；锚点队列。

复算：`make p6-ac6-dashboard && make p6-report`
