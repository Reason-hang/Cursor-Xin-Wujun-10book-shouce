#!/usr/bin/env python3
"""D6《方案决策与裁决记录》v0.9 交付副本。"""
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "out"
DELIVER = ROOT.parent / "最终所有交付物"

BODY = f"""# 方案决策与裁决记录 v0.9

> 更新：{date.today().isoformat()}

## 待裁决（阻塞 D1 v1.0 目录）

| ID | 议题 | 选项 | 状态 |
|---|---|---|---|
| R-D10-01 | D10 独立第 10 柱 | **A** 保留 10 柱，证据门记 D6 例外 / **B** 9 柱并入 D08-1 | **待你**（见 `ledger/R-D10-01_裁决附件_AB对比.md`） |
| R-P4-01 | P4 抽查 20 张 Y/N | `ledger/P4_抽查20张.csv` | **待你** |
| R-P6-01 | 锚点↔claim 质控 | `ledger/P6_锚点修探针队列.csv`（3 条 P1） | **待你批后修锚** |

## 已记录决策

| 日期 | 决策 | 依据 |
|---|---|---|
| 2026-10-27 | P5 场景 ID 按手册 D01→D10 重排为 S-001–046 | `ledger/P5_场景ID重排_手册章序.md` |
| 2026-10-27 | P5 v0.9 集成 D1/D2 至 `最终所有交付物/` | `ledger/P5_T-P5-10_集成记录.md` |
| 2026-10-27 | D10 三道门总裁决 **fail**（证据 2.36%）仍完成 P5 第 10 章过程稿 | `ledger/P4_D10三道门裁决.md` |
| 2026-10-27 | K 冻结 493；P4 κ=0.839（13 manual override） | `ledger/P4_K卡冻结_2026-10-27.md` |
| 2026-10-27 | P6 双向矩阵机械预检 PASS；抽检召回样本 130 条 | `ledger/P6_双向矩阵_机械预检.md`、`P6_抽检召回样本.csv` |
| 2026-10-27 | SG1 无 K 卡纳入冻结（范围缺口登记） | `ledger/P6_SG1_来信1论点缺口.md` |
| 2026-10-27 | B3：P3–P6 阶段追加段入库 | `prompts/phase_append_P3.md`–`P6.md` |
| 2026-10-27 | G10 去向机械 100%（5051 命中） | `make p6-g10-refresh`；口径 `ledger/P6_G10去向登记口径.md` |

## 变更日志

- **v0.9**：P6 启动；D3/D4/D6 首版入 `最终所有交付物/`；EP-0 B3 自测扩至角色/阶段段/机读字典。
"""


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    DELIVER.mkdir(parents=True, exist_ok=True)
    for d in (OUT, DELIVER):
        (d / "方案决策与裁决记录_v0.9.md").write_text(BODY, encoding="utf-8")
    print("p6 d6 → out + 最终所有交付物")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
