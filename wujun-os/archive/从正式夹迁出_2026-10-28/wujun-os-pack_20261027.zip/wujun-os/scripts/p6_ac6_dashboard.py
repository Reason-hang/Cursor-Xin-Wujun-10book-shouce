#!/usr/bin/env python3
"""生成 P6 AC-6 状态看板（过程件，供 D4 与人审对照）。"""
import csv
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "ledger/P6_AC6_状态看板.md"


def recall_pending() -> int:
    p = ROOT / "ledger/P6_抽检召回样本.csv"
    if not p.is_file():
        return -1
    rows = list(csv.DictReader(p.open(encoding="utf-8")))
    return sum(1 for r in rows if r.get("recall_status", "pending") == "pending")


def g10_ok() -> bool:
    p = ROOT / "ledger/P6_G10关键词去向统计.md"
    return p.is_file() and "待处理 | 0 |" in p.read_text(encoding="utf-8")


def main() -> int:
    rp = recall_pending()
    lines = [
        f"# P6 AC-6 状态看板（{date.today().isoformat()}）",
        "",
        "| AC | 项 | 状态 | 证据/下一步 |",
        "|---|---|---|---|",
        "| 6.1 | G0–G9 全重跑 | 部分 | `make gates` + selftest 子集 |",
        "| 6.2 | 核心论点覆盖 | 机械 PASS | `make p6-bidir-matrix`；语义待回读 |",
        f"| 6.3 | 抽检召回 | {'未闭环' if rp else '样本全 pass' if rp == 0 else '未知'} | pending={rp}/130 → `P6_抽检召回工作册.md` |",
        f"| 6.4 | 关键词反查 | {'机械达标' if g10_ok() else '未达标'} | `make p6-g10-refresh` |",
        "| 6.5 | 数理映射 | PASS | `make p6-math-audit` 50/50 |",
        "| 6.6 | 应用 5 场景 | PASS | `make p6-app-lint` + ledger 演练稿 |",
        "| 6.7 | 滑窗重复 | PASS | `make p6-dup-lint` |",
        "| 6.8 | 锚点 | PASS | `make verify-anchors` |",
        "| 6.9 | 对抗审查 | 待签收 | `P6_对抗式审查_签收表.md` |",
        "| 6.10 | 用户试用 | 待你 | `P6_用户试用与抽查指引.md` |",
        "",
        "**阻塞 P7**：D10 A/B（`R-D10-01_裁决附件_AB对比.md`）；P4 20 张；锚点队列。",
        "",
        "复算：`make p6-ac6-dashboard && make p6-report`",
    ]
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"p6 ac6 dashboard → {OUT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
